<?php
// Iniciamos la clase de la cesta
include_once 'session.php';
$cart = new Cart;
?>

<style>
    .container{padding: 20px;}
    .cart-link{width: 100%;text-align: right;display: block;font-size: 22px;}
    .font{font-family: tahoma;}
</style>

<div class="container">

    <a href="cart.php" class="btn btn-sm btn-warning" title="Ver Carta"><i class="fa fa-shopping-cart"></i> Ver Cesta (<?=$cart->total_items()?>)</a>

    <h1>Mis Productos</h1>

    <br />
    <div class="row row-fluid">
        <?php
        //get rows query
        $query = $db->query("SELECT * FROM mis_productos ORDER BY id ASC LIMIT 50");
        if($query->num_rows > 0){ 
            while($row = $query->fetch_assoc()){
        ?>
        <div class="item col-lg-4" style="padding: 10px;">
            <div class="thumbnail">
                <div class="caption">
                    <img src="<?=$row["image"]?>" width="100%" class="img-responsive"/>
                    <h4 class="list-group-item-heading"><?=utf8_encode($row["name"]); ?></h4>
                    <p class="list-group-item-text"><?=utf8_encode($row["description"]); ?></p>
                    <div class="row">
                        <div class="col-md-6">
                            <p class="lead"><?='$'.$row["price"]; ?></p>
                        </div>
                        <div class="col-md-6 text-right">
                            <a class="btn btn-sm btn-success" href="AccionCarta.php?action=addToCart&id=<?=$row["id"]; ?>"><i class="fa fa-shopping-cart"></i> Agregar</a>
                        </div>
                    </div>
                </div>
                <hr />
            </div>
        </div>
        <?php } }else{ ?>
        <p>Producto(s) no existe.....</p>
        <?php } ?>
    </div>
 
</div>