<!--

Author: Rafael Argüelles
Author Mail: rafaelargdev@gmail.com


-->

<!DOCTYPE HTML>

<html lang="es">



<head>

	<title>Biomentha Cosmética Natural</title>

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta charset="utf-8">

	<meta name="keywords" content="biomentha, cosmetica natural, productos cosmeticos, shampoo solido, shampoo para mascotas, lociones, san luis potosi, slp" />

	<script>

		addEventListener("load", function () {

			setTimeout(hideURLbar, 0);

		}, false);



		function hideURLbar() {

			window.scrollTo(0, 1);

		}

	</script>



	<!-- Bootstrap Core CSS -->

	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

	<!-- pop up box -->

	<link href="css/popuo-box.css" rel="stylesheet" type="text/css" media="all" />

	<!-- gallery -->

	<link rel="stylesheet" href="css/smoothbox.css" type='text/css' media="all" />

	<link href="css/style.css" rel='stylesheet' type='text/css' />

	<!-- font-awesome icons -->

	<link href="css/fontawesome-all.min.css" rel="stylesheet">

	<!-- //Custom Theme files -->

	<!-- online fonts -->

	<!-- titles -->

	<link href="//fonts.googleapis.com/css?family=Dancing+Script:400,700" rel="stylesheet">

	<!-- body -->

	<link href="//fonts.googleapis.com/css?family=Gentium+Basic:400,400i,700,700i" rel="stylesheet">

</head>

<body>