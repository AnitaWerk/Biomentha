	<!-- footer -->

	<footer class="py-md-5 py-3">

		<div class="container">

			<!-- footer grid top -->

			<div class="footerv2-w3ls text-center">

				<h4 class="w3ls-title text-capitalize py-3">Encuéntranos también en:</h4>

				<ul class="social-iconsv2 agileinfo">

					<li>

						<a href="https://www.facebook.com/BioMenthaCosmeticaNatural/">

							<i class="fab fa-facebook"></i>

						</a>

					</li>

					<li>

						<a href="https://www.instagram.com/biomenthacosmetica/?hl=es">

							<i class="fab fa-instagram"></i>

						</a>

					</li>

					<li>

						<a href="https://api.whatsapp.com/send?phone=524445820610&text=Hola%20quiero%20saber%20m%C3%A1s">

							<i class="fab fa-whatsapp"></i>

						</a>

					</li>

					

				</ul>

			</div>

			<!-- copyright -->

			<div class="cpy-right text-center pt-5">

				<p>Copyright© 2020 Biomentha. Todos Los Derechos Reservados| Este sitio web fue desarrollado por

					<a href="http://papayadesign.com.mx">Papaya Design</a>

				</p>

			</div>

			<!-- //copyright -->

		</div>

	</footer>

	<!-- //footer -->