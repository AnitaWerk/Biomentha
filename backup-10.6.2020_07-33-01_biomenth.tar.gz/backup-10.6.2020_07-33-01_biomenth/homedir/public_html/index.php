<?php

require_once('config/constants.php');

include DIR_LAYOUTS . 'meta.php';

include DIR_LAYOUTS . 'header.php';

include DIR_LAYOUTS . 'home.php';

include DIR_LAYOUTS . 'footer.php';

include DIR_LAYOUTS . 'scripts.php';
