-- MySQL dump 10.17  Distrib 10.3.23-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: biomenth_db
-- ------------------------------------------------------
-- Server version	10.3.23-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `biomenth_db`
--


--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `street` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suburb` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `additional_address` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` (`id`, `name`, `email`, `phone`, `address`, `street`, `suburb`, `postal_code`, `additional_address`, `created`, `modified`, `status`) VALUES (1,'Usuario Demo','demo-demo@gmail.com','900099900','Quito, EC, Ecuador',NULL,NULL,NULL,NULL,'2018-02-17 08:21:25','2018-02-17 08:21:25','1'),(14,'CÃ©sar Rojas','cesar.ramone@gmail.com','+584244976403','Conjunto Residencial Los Guayos II, Edif. Moron, Apto. 2A-03 PB','CONJUNTO RESIDENCIAL LOS GUAYOS II, EDIF. MORON, APTO. 2A-03 PB','CANCUN','2003','','2020-09-28 20:03:54','2020-09-28 20:03:54','1');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mis_productos`
--

DROP TABLE IF EXISTS `mis_productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mis_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `price` float(10,2) NOT NULL,
  `image` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mis_productos`
--

LOCK TABLES `mis_productos` WRITE;
/*!40000 ALTER TABLE `mis_productos` DISABLE KEYS */;
INSERT INTO `mis_productos` (`id`, `name`, `description`, `price`, `image`, `created`, `modified`, `status`) VALUES (1,'Shampoo Sólido Mango - Jamaica - Chico','Para cabello seco y poroso',70.00,'images/productos/shampoo-mango-jamaica.jpg','2016-08-17 08:21:25','2016-08-17 08:21:25','1'),(2,'Shampoo Sólido Mango - Jamaica - Grande','Para cabello seco y poroso',100.00,'images/productos/shampoo-mango-jamaica.jpg','2016-08-17 08:21:25','2016-08-17 08:21:25','1'),(3,'Shampoo Sólido Mango - Jamaica - Jumbo','Para cabello seco y poroso',140.00,'images/productos/shampoo-mango-jamaica.jpg','2016-08-17 08:21:25','2016-08-17 08:21:25','1'),(4,'Shampoo Sólido Avena - Miel - Chico','Para pieles sensibles y cabello normal',70.00,'images/productos/shampoo-avena-miel.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(5,'Shampoo Sólido Avena - Miel - Grande','Para pieles sensibles y cabello normal',100.00,'images/productos/shampoo-avena-miel.jpg','0000-00-00 00:00:00','0000-00-00 00:00:00','1'),(6,'Shampoo Sólido Avena - Miel - Jumbo','Para pieles sensibles y cabello normal',140.00,'images/productos/shampoo-avena-miel.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(7,'Shampoo Sólido Romero','Ideal para la caída del cabello',70.00,'images/productos/shampoo-romero.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(8,'Cepillo Corporal','Para utilizar en todo el cuerpo y ayudar a remover impurezas',110.00,'images/productos/cepillo-corporal-sin-mango.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(9,'Cepillo para el cabello','Para utilizar en el cabello seco o húmedo',110.00,'images/productos/cepillo-para-tu-pela-hermosa.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(10,'Cepillo Facial','Delicado a la hora de masajear el rostro',60.00,'images/productos/cepillo-para-tu-cara.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(11,'Cepillo corporal con mango','Para mayor comodidad',140.00,'images/productos/cepillo-corporal-con-mango.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(12,'Acondicionador Aguacate','Humectante',120.00,'images/productos/acondicionador-aguacate.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(13,'Acondicionador Betabel','Fortalece',120.00,'images/productos/shampoo-betabel.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(14,'Acondicionador Papaya - Plátano','Da brillo',120.00,'images/productos/acondicionador-platano-papaya.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(15,'Crema corporal','Crema hidratante y suavizante para todo tipo de piel',100.00,'images/productos/crema-solida1.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(16,'Shampoo para mascota','Especialmente elaborado para el pelaje de las mascotas',100.00,'images/productos/perro.png','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(17,'Vela','Vela',70.00,'images/productos/velas-de-masaje.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(18,'Mascarilla capilar sólida','Mascarilla capilar sólida',60.00,'images/productos/mascarilla-capilar.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1'),(19,'Jabonera','Conserva tus productos en un lugar seguro',100.00,'images/productos/jabonera.jpg','2020-06-11 00:00:00','2020-06-11 00:00:00','1');
/*!40000 ALTER TABLE `mis_productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orden`
--

DROP TABLE IF EXISTS `orden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orden` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `total_price` float(10,2) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` enum('1','0') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `token` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `orden_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `clientes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orden`
--

LOCK TABLES `orden` WRITE;
/*!40000 ALTER TABLE `orden` DISABLE KEYS */;
INSERT INTO `orden` (`id`, `customer_id`, `total_price`, `created`, `modified`, `status`, `token`) VALUES (1,14,70.00,'2020-09-28 20:03:54','2020-09-28 20:03:54','1','C1RjzRcDD8');
/*!40000 ALTER TABLE `orden` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orden_articulos`
--

DROP TABLE IF EXISTS `orden_articulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orden_articulos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(5) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `orden_articulos_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orden` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orden_articulos`
--

LOCK TABLES `orden_articulos` WRITE;
/*!40000 ALTER TABLE `orden_articulos` DISABLE KEYS */;
INSERT INTO `orden_articulos` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES (1,1,4,1,70.00);
/*!40000 ALTER TABLE `orden_articulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pagos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `bank` varchar(20) DEFAULT NULL,
  `datep` date DEFAULT NULL,
  `ref` varchar(20) DEFAULT NULL,
  `amount` decimal(18,5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orden_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` (`id`, `order_id`, `bank`, `datep`, `ref`, `amount`) VALUES (1,1,'MERCADOPAGO','2020-09-28','30102189',70.00000);
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'biomenth_db'
--

--
-- Dumping routines for database 'biomenth_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-06  7:33:02
